// Constantes y funciones de procesamiento de datos

MARGIN = {
    top: 30,
    bottom: 50,
    right: 20,
    left: 15,
}

const WIDTH_1 = 800;
const HEIGHT_1 = 600;
const WIDTH_2 = 1000;
const HEIGHT_2 = 600;
const WIDTH_VIS1 = WIDTH_1 - MARGIN.left - MARGIN.right;
const HEIGHT_VIS1 = HEIGHT_1 - MARGIN.top - MARGIN.bottom;
const WIDTH_VIS2 = WIDTH_2 - MARGIN.left - MARGIN.right;
const HEIGHT_VIS2 = HEIGHT_2 - MARGIN.top - MARGIN.bottom;

const DATA = "https://raw.githubusercontent.com/mati-gonz/examen-infovis/main/assets/data/CR7_DATA.csv";
const mesesTemporadaRegular = ["Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
const colores = ["green", "red", "blue", "black"]

var parseTime = d3.timeParse("%m/%d/%Y")

var parseData= function(d) {
    return {
        season: d.Season,
        competition: d.Competition,
        date: parseTime(d.Date),
        club: d.Club,
    };
}

// Construccion de las visualizaciones

const svg1 = d3.select("#container-vis-1")
    .append("svg")
    .attr("width", WIDTH_1)
    .attr("height", HEIGHT_1)
    .attr("class", "vis-1");

const svg2 = d3.select("#container-vis-2")
    .append("svg")
    .attr("width", WIDTH_2)
    .attr("height", HEIGHT_2)
    .attr("class", "vis-2")
    .attr("transform", `translate(${MARGIN.left}, ${MARGIN.top})`)
  
const contenedorEjeX2 = svg2
    .append("g")
    .attr("transform", `translate(60, ${HEIGHT_VIS2})`)


function joinData(data) {
    const grupoSeason = d3.groups(data, d => d.season)
    const grupoEquipo = d3.groups(data, d => d.club)
    console.log(grupoEquipo)

    // constantes de los ejes

    //console.log(grupoEquipo.length)

    const yScale = d3
        .scaleBand()
        .domain(grupoEquipo.map(d => d[0]))
        .rangeRound([0, HEIGHT_VIS2])
        .paddingOuter(0.1)
        .paddingInner(0.4)
        .align(0.5)
    
    const xScale = d3
        .scaleLinear()
        .domain([0, d3.max(grupoEquipo, d => d[1].length)])
        .range([0, WIDTH_VIS2])
    
    const COLOR = d3.scaleOrdinal(colores).domain(data.map(d => d.club))

    const ejeX2 = d3.axisBottom(xScale);

    contenedorEjeX2
        .call(ejeX2)
        .selectAll("text")
        .attr("font-size", 15)

    const enter_and_update = svg2
        .selectAll(".barra")
        .data(grupoEquipo)
        .join("g")
        .attr("transform", d => `translate(${MARGIN.left}, ${yScale(d[0])})`)
        .attr("class", "barra")
    
    enter_and_update
        .append("rect")
        .attr("width", d => xScale(d[1].length))
        .attr("height", yScale.bandwidth())
        .attr("fill", d => COLOR(d[0]))
        .attr('x', 60)

    const imageHeight = 100;
    enter_and_update
        .append("svg:image")
        .attr('x', 0)
        .attr('y', (yScale.bandwidth()/2) - imageHeight/2)
        .attr('width', 50)
        .attr('height', imageHeight)
        .attr("xlink:href", d => {
            return `./assets/team_images/${d[0]}.png`
        })
    
    



}

// Carga de datos

const datos = d3.csv(DATA, parseData)
    .then(data => {
        joinData(data);
    })
    .catch(error => {
        console.log(error);
    });